"""DaySpan - A simple tool to calculate days between dates."""

from .calculator import calculate_days, parse_date

__version__ = '1.0.0'
__author__ = 'Your Name'
__all__ = ['calculate_days', 'parse_date']